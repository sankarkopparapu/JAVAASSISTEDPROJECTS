export class UserModel{
    citizenId:number;
    name:string;
    dob:string;
    mobileno:string;
    address:string;
    emailid:string;
    gender:string;

}